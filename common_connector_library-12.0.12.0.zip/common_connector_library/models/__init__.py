from . import res_partner
from . import sale_order
from . import sale_order_line
from . import product_product
from . import stock_inventory
from . import stock_quant_package
from . import stock_picking
from . import product_pricelist
from . import account_invoice
from . import product_attribute
from . import product_attribute_value
from . import account_bank_statement_line

