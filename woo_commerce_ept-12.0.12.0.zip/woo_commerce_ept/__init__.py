from . import wordpress_xmlrpc
from . import python_magic_0_4_11
from . import img_upload
from . import woocommerce
from . import models
from . import wizard


